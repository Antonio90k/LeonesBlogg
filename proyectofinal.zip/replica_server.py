from flask import Flask, request, jsonify
import os
import sys
import requests

from db_utils import get_connection, init_db

app = Flask(__name__)

DB_PATH = sys.argv[1] if len(sys.argv) > 1 else os.path.join("db", "replica1.db")
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 5001

PRIMARY_URL = "http://localhost:5000"

conn = get_connection(DB_PATH)
init_db(conn)


def get_last_event_id():
    cur = conn.cursor()
    cur.execute("SELECT value FROM replica_meta WHERE key = 'last_event_id'")
    row = cur.fetchone()
    if not row:
        return 0
    return int(row["value"])


def set_last_event_id(event_id):
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO replica_meta (key, value) VALUES ('last_event_id', ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (str(event_id),)
    )
    conn.commit()


def apply_event(event_id, event_type, payload):
    cur = conn.cursor()

    if event_type == "CREATE_POST":
        cur.execute(
            "INSERT OR IGNORE INTO posts (id, user_id, title, content, image_filename, created_at) "
            "VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)",
            (
                payload["post_id"],
                payload["user_id"],
                payload["title"],
                payload["content"],
                payload.get("image_filename"),
            )
        )

    elif event_type == "REACT_POST":
        cur.execute(
            """
            INSERT INTO reactions (user_id, post_id, reaction_type)
            VALUES (?, ?, ?)
            ON CONFLICT(user_id, post_id) DO UPDATE SET reaction_type = excluded.reaction_type
            """,
            (payload["user_id"], payload["post_id"], payload["reaction_type"])
        )

    elif event_type == "COMMENT_POST":
        cur.execute(
            "INSERT OR IGNORE INTO comments (id, user_id, post_id, content, created_at) "
            "VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)",
            (
                payload["comment_id"],
                payload["user_id"],
                payload["post_id"],
                payload["content"],
            )
        )

    elif event_type == "DELETE_POST":
        cur.execute("DELETE FROM posts WHERE id = ?", (payload["post_id"],))
        cur.execute("DELETE FROM reactions WHERE post_id = ?", (payload["post_id"],))
        cur.execute("DELETE FROM comments WHERE post_id = ?", (payload["post_id"],))

    conn.commit()
    set_last_event_id(event_id)


@app.route("/replicate", methods=["POST"])
def replicate():
    data = request.get_json()
    event_id = data["event_id"]
    event_type = data["event_type"]
    payload = data["payload"]
    apply_event(event_id, event_type, payload)
    return jsonify({"status": "ok"})


@app.route("/catchup")
def catchup():
    last_id = get_last_event_id()
    try:
        r = requests.get(f"{PRIMARY_URL}/sync", params={"last_event_id": last_id}, timeout=3)
        events = r.json()
        for ev in events:
            apply_event(ev["id"], ev["event_type"], ev["payload"])
        return jsonify({"status": "ok", "applied_events": len(events)})
    except Exception as e:
        return jsonify({"status": "error", "error": str(e)}), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=PORT, debug=True)
